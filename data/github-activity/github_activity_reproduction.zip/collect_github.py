import json,subprocess,concurrent.futures,pathlib,datetime,csv,collections,time
BASE=pathlib.Path.cwd(); W=BASE/'work'; O=BASE/'outputs'; W.mkdir(exist_ok=True); O.mkdir(exist_ok=True); (W/'repos').mkdir(exist_ok=True)
repos=[]
for org in ['openai','anthropics']:
 snapshot=W/f'{org}-repos.json'
 if not snapshot.exists():
  supplied=pathlib.Path(__file__).resolve().parent/f'{org}-repos.json'
  if supplied.exists():snapshot.write_bytes(supplied.read_bytes())
  else:snapshot.write_text(subprocess.check_output(['gh','api','--paginate',f'orgs/{org}/repos?type=public&per_page=100'],text=True))
 for r in json.load(open(W/f'{org}-repos.json')):
  if not r['fork']: repos.append(r)
fields=['full_name','default_branch','created_at','pushed_at','size','archived','fork','html_url']
with open(O/'repository_inventory.csv','w') as f:
 wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader();wr.writerows({k:r[k] for k in fields} for r in repos)
def run(r):
 name=r['full_name']; dest=W/'repos'/name.replace('/','__'); out=W/(name.replace('/','__')+'.json')
 if out.exists():
  cached=json.load(open(out))
  if cached['status']!='error' and not (cached['status']=='outside_period' and r['pushed_at']>='2025-01-01'):return cached
 result={'repo':name,'status':'ok','rows':[],'default_branch':r['default_branch']}
 if r['pushed_at']<'2025-01-01':
  result['status']='outside_period';out.write_text(json.dumps(result));return result
 try:
  if not (dest/'.git').exists():
   p=subprocess.run(['git','-c','http.version=HTTP/1.1','clone','--single-branch','--no-checkout','--quiet',r['clone_url'],str(dest)],capture_output=True,text=True,timeout=600)
   if p.returncode: raise Exception(p.stderr[-1500:])
  p=subprocess.run(['git','-C',str(dest),'log','--since-as-filter=2025-01-01T00:00:00Z','--until=2026-08-31T23:59:59Z','--format=@@@%H|%cI|%aI|%P','--numstat','--find-renames'],capture_output=True,text=True,timeout=300)
  if p.returncode:
   refs=subprocess.run(['git','-C',str(dest),'ls-remote','origin'],capture_output=True,text=True,timeout=60)
   if refs.returncode==0 and not refs.stdout.strip():
    result['status']='empty';out.write_text(json.dumps(result));return result
   raise Exception(p.stderr[-1500:])
  cur=None
  for line in p.stdout.splitlines():
   if line.startswith('@@@'):
    sha,cd,ad,parents=line[3:].split('|');cur={'sha':sha,'committer_date':cd,'author_date':ad,'merge':len(parents.split())>1,'additions':0,'deletions':0,'files':[]};result['rows'].append(cur)
   elif cur and '\t' in line:
    a,d,file=line.split('\t',2)
    if a.isdigit() and d.isdigit():
     cur['additions']+=int(a);cur['deletions']+=int(d);cur['files'].append([file,int(a),int(d)])
  result['rename_detection']=True
  result['head']=subprocess.check_output(['git','-C',str(dest),'rev-parse','HEAD'],text=True).strip()
 except Exception as e:result['status']='error';result['error']=str(e)
 out.write_text(json.dumps(result));return result
if __name__=='__main__':
 start=time.time(); results=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
  for f in concurrent.futures.as_completed([ex.submit(run,r) for r in repos]):
   r=f.result();results.append(r);print(len(results),'/',len(repos),r['repo'],r['status'],len(r['rows']),round(time.time()-start),flush=True)
 (W/'results.json').write_text(json.dumps(results))
