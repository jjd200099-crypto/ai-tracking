import pathlib,json,collections,csv,datetime
W=pathlib.Path('work');O=pathlib.Path('outputs'); agg=collections.defaultdict(lambda:[0,0,0,0]);ra=collections.defaultdict(lambda:[0,0,0]);fa=collections.defaultdict(int); ca=[]; status=collections.Counter()
for p in list(W.glob('openai__*.json'))+list(W.glob('anthropics__*.json')):
 r=json.load(open(p));status[r['status']]+=1
 if r['status']!='ok':continue
 repo=r['repo'];org=repo.split('/')[0]
 for c in r['rows']:
  dt=datetime.datetime.fromisoformat(c['committer_date']).astimezone(datetime.timezone.utc);month=dt.strftime('%Y-%m')
  if not '2025-01'<=month<='2026-08':continue
  a=agg[org,month];a[0]+=1; a[3]+=int(c['merge']);rr=ra[repo,month];rr[0]+=1
  if not c['merge']:
   lines=c['additions']+c['deletions'];a[1]+=c['additions'];a[2]+=c['deletions'];rr[1]+=lines
   if month=='2026-08':
    ca.append({'repo':repo,'sha':c['sha'],'date':c['committer_date'],'lines_changed':lines,'url':f'https://github.com/{repo}/commit/{c["sha"]}'})
    for fn,ad,de in c['files']:fa[repo,fn]+=ad+de
  else:rr[2]+=1

def write(name,fields,rows):
 with open(O/name,'w') as f:
  wr=csv.writer(f);wr.writerow(fields);wr.writerows(rows)
write('monthly_totals.csv',['organization','month','commits','additions','deletions','lines_changed','merge_commits'],[(o,m,a,d,e,d+e,g) for (o,m),(a,d,e,g) in sorted(agg.items())])
write('repository_monthly.csv',['repository','month','commits','lines_changed','merge_commits'],[(r,m,*v) for (r,m),v in sorted(ra.items())])
write('august_files.csv',['repository','file','lines_changed'],[(r,f,v) for (r,f),v in sorted(fa.items(),key=lambda x:x[1],reverse=True)])
write('august_top_commits.csv',['repo','sha','date','lines_changed','url'],[[c[k] for k in ['repo','sha','date','lines_changed','url']] for c in sorted(ca,key=lambda c:c['lines_changed'],reverse=True)])
print('STATUS',status)
for org in ['openai','anthropics']:
 print(org)
 for month in ['2026-05','2026-06','2026-07','2026-08']:print(month,agg[org,month],sum(agg[org,month][1:3]))
 print('TOP AUG',sorted([(r,v) for (r,m),v in ra.items() if m=='2026-08' and r.startswith(org+'/')],key=lambda x:x[1][1],reverse=True)[:10])
