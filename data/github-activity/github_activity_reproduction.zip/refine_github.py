import pathlib,subprocess,json,concurrent.futures
W=pathlib.Path('work')
def refine(p):
 r=json.load(open(p))
 if r['status']!='ok' or r.get('rename_detection'):return
 dest=W/'repos'/r['repo'].replace('/','__')
 cmd=['git','-C',str(dest),'log','--since-as-filter=2025-01-01T00:00:00Z','--until=2026-08-31T23:59:59Z','--format=@@@%H|%cI|%aI|%P','--numstat','--find-renames']
 pr=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
 if pr.returncode:print(r['repo'],pr.stderr,flush=True);return
 rows=[];cur=None
 for line in pr.stdout.splitlines():
  if line.startswith('@@@'):
   sha,cd,ad,parents=line[3:].split('|');cur={'sha':sha,'committer_date':cd,'author_date':ad,'merge':len(parents.split())>1,'additions':0,'deletions':0,'files':[]};rows.append(cur)
  elif cur and '\t' in line:
   a,d,file=line.split('\t',2)
   if a.isdigit() and d.isdigit():cur['additions']+=int(a);cur['deletions']+=int(d);cur['files'].append([file,int(a),int(d)])
 r['rows']=rows;r['rename_detection']=True;p.write_text(json.dumps(r));print(r['repo'],len(rows),flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(refine,list(W.glob('openai__*.json'))+list(W.glob('anthropics__*.json'))))
